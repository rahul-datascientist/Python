OpenIntro
=========

Data sets (and perhaps other utilities) to accompany Open Intro Stats with Randomization and Simulation
