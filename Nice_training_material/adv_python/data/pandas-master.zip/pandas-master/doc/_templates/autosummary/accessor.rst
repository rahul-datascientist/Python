{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module.split('.')[0] }}

.. automethod:: {{ [module.split('.')[1], objname]|join('.') }}
