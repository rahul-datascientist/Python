#### Code Sample, a copy-pastable example if possible

#### Expected Output

#### output of ``pd.show_versions()``

